// ---------- دوال المساعدة: hashCode ----------
if (typeof String.prototype.hashCode === 'undefined') {
  String.prototype.hashCode = function() {
    var hash = 0, i, chr;
    if (this.length === 0) return hash;
    for (i = 0; i < this.length; i++) {
      chr = this.charCodeAt(i);
      hash = ((hash << 5) - hash) + chr;
      hash |= 0;
    }
    return Math.abs(hash);
  };
}
// ---------- الإعدادات الأساسية ----------
const SPREADSHEET_ID = '1B6um1tNw0Uh4NJvLjF5zUX6palzubXv1UeH5gSIt_Go';
const SHEET_NAME = 'Commandes';
const STORE_EMAIL = 'benaakrabahcene@gmail.com';
const STORE_NAME = 'VOTRE BOUTIQUE';
const ORDERS_API_SECRET_PROPERTY = 'ORDERS_API_SECRET';
const ORDER_STATUSES = ['En attente', 'Confirmée', 'En cours de livraison', 'Livrée'];

// ---------- دالة الدخول الرئيسية ----------
function doPost(e) {
  var requestId = null;
  var lock = LockService.getScriptLock();
  try {
    console.log('=== DÉBUT TRAITEMENT COMMANDE ===');
    if (!e || !e.postData || !e.postData.contents) {
      throw new Error('Aucun postData fourni');
    }
    const data = JSON.parse(e.postData.contents);

    // كل الاتصالات تمر عبر Worker وتحتاج Secret.
    if (!isValidOrdersApiSecret(data.secret)) {
      return sendResponse('error', 'Accès non autorisé');
    }

    // أوامر الإدارة (list/get/updateStatus/setup) لها مسار API مستقل.
    // Worker هو الذي يحدد StoreKey الموثوق، وليس المتصفح.
    if (data.action && data.action !== 'createOrder') {
      const apiResult = ordersApi(data);
      return ContentService.createTextOutput(JSON.stringify(apiResult))
        .setMimeType(ContentService.MimeType.JSON);
    }

    // API متعددة المتاجر: الطلب يجب أن يحمل StoreKey الذي حدده Worker.
    const storeKey = normalizeStoreKey(data.storeKey);
    if (!storeKey) {
      return sendResponse('error', 'StoreKey obligatoire');
    }

    const orderData = data.data || data.order || data;
    orderData.storeKey = storeKey;
    if (data.storeName) orderData.storeName = String(data.storeName).trim();

    requestId = generateRequestId(orderData, storeKey);
    console.log('🆔 Request ID:', requestId);

    lock.waitLock(30000);
    console.log('🔒 Lock obtenu');

    if (isRequestProcessed(requestId)) {
      console.log('⚠️ Requête déjà traitée (properties):', requestId);
      lock.releaseLock();
      return sendResponse('success', 'Commande déjà traitée (properties)', { requestId: requestId });
    }

    if (isRequestInSheet(requestId, storeKey)) {
      console.log('⚠️ Requête déjà dans le sheet:', requestId);
      markRequestAsCompleted(requestId);
      lock.releaseLock();
      return sendResponse('success', 'Commande déjà enregistrée dans la feuille', { requestId: requestId });
    }

    markRequestAsProcessing(requestId);
    const orderId = generateOrderId();
    console.log('📋 Order ID généré:', orderId);

    const sheetResult = saveToSpreadsheet(orderData, orderId, requestId, storeKey);
    console.log('💾 Résultat sheet:', sheetResult);

    if (!isEmailSentForRequest(requestId)) {
      console.log('📧 Envoi de l\'email...');
      const emailResult = sendSingleEmail(orderData, orderId, STORE_EMAIL, orderData.storeName || STORE_NAME);
      if (emailResult.success) {
        markEmailAsSent(requestId);
      } else {
        console.warn('⚠️ Probleme envoi email:', emailResult);
      }
      console.log('✅ Résultat email:', emailResult);
    } else {
      console.log('⚠️ Email déjà envoyé pour cette requête');
    }

    markRequestAsCompleted(requestId);
    lock.releaseLock();
    console.log('🔓 Lock released');

    return sendResponse('success', 'Commande envoyée avec succès', {
      orderId: orderId,
      sheetSaved: true,
      requestId: requestId,
      storeKey: storeKey
    });
  } catch (error) {
    console.error('❌ Erreur:', error);
    try { lock.releaseLock(); } catch (e) { }
    if (requestId) cleanupRequest(requestId);
    return sendResponse('error', 'Erreur lors de l\'envoi de la commande: ' + error.toString());
  }
}

// ---------- توليد Request ID ثابت ----------
function generateRequestId(data, storeKey) {
  const customer = (data.customerPhone || '').toString().trim();
  const address = (data.customerAddress || '').toString().trim();
  const itemsString = JSON.stringify(data.items || []);
  const total = (data.total || 0).toString();
  const raw = normalizeStoreKey(storeKey) + '|' + customer + '|' + address + '|' + itemsString + '|' + total;
  return 'REQ_' + raw.hashCode();
}

// ---------- توليد رقم طلب فريد ----------
function generateOrderId() {
  const timestamp = Date.now();
  const random = Math.floor(Math.random() * 10000);
  return 'ORD-' + timestamp + '-' + random;
}

// ---------- التحقق من Script Properties ----------
function isRequestProcessed(requestId) {
  try {
    const props = PropertiesService.getScriptProperties();
    const status = props.getProperty(requestId);
    console.log('🔍 Vérification requête (props):', requestId, '->', status);
    return status === 'DONE' || status === 'PROCESSING';
  } catch (err) {
    console.error('Erreur vérification requête:', err);
    return false;
  }
}
function markRequestAsProcessing(requestId) {
  try {
    const props = PropertiesService.getScriptProperties();
    props.setProperty(requestId, 'PROCESSING');
    console.log('🔄 Marked PROCESSING:', requestId);
  } catch (err) {
    console.error('Erreur marquage traitement:', err);
  }
}
function markRequestAsCompleted(requestId) {
  try {
    const props = PropertiesService.getScriptProperties();
    props.setProperty(requestId, 'DONE');
    console.log('✅ Marked DONE:', requestId);
  } catch (err) {
    console.error('Erreur marquage complétion:', err);
  }
}
function cleanupRequest(requestId) {
  try {
    const props = PropertiesService.getScriptProperties();
    props.deleteProperty(requestId);
    props.deleteProperty(requestId + '_email');
    console.log('🧹 Requête nettoyée:', requestId);
  } catch (err) {
    console.error('Erreur nettoyage:', err);
  }
}

// ---------- التحقق من وجود requestId داخل الشيت ----------
function isRequestInSheet(requestId, storeKey) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    const sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) return false;
    ensureOrderSheetSchema(sheet);
    const idx = getHeaderIndexes(sheet);
    if (idx.RequestID === -1) return false;
    const lastRow = sheet.getLastRow();
    if (lastRow < 2) return false;
    const values = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).getValues();
    const targetStore = normalizeStoreKey(storeKey);
    return values.some(row =>
      String(row[idx.RequestID] || '') === String(requestId) &&
      (!targetStore || normalizeStoreKey(row[idx.StoreKey]) === targetStore)
    );
  } catch (err) {
    console.error('Erreur lecture sheet pour requestId:', err);
    return false;
  }
}

// ---------- إدارة الإيميل المرسل ----------
function markEmailAsSent(requestId) {
  try {
    const props = PropertiesService.getScriptProperties();
    props.setProperty(requestId + '_email', 'SENT');
    console.log('📫 Email marqué comme envoyé:', requestId);
  } catch (err) {
    console.error('Erreur marquage email:', err);
  }
}
function isEmailSentForRequest(requestId) {
  try {
    const props = PropertiesService.getScriptProperties();
    const val = props.getProperty(requestId + '_email');
    console.log('🔍 Vérification email:', requestId, '->', val);
    return val === 'SENT';
  } catch (err) {
    console.error('Erreur vérification email:', err);
    return false;
  }
}

// ---------- إرسال إيميل مرة واحدة ----------
function sendSingleEmail(data, orderId, storeEmail, storeName) {
  try {
    const remainingQuota = MailApp.getRemainingDailyQuota();
    console.log('📊 Quota email restant:', remainingQuota);
    if (remainingQuota < 1) return { success: false, message: 'Quota e-mail épuisé' };
    const subject = `🛍️ Nouvelle Commande - ${storeName} - ${orderId}`;
    const body = createEmailBody(data, orderId);
    MailApp.sendEmail({
      to: storeEmail,
      subject: subject,
      htmlBody: body,
      replyTo: data.customerPhone || storeEmail
    });
    console.log('✅ Email envoyé avec succès à:', storeEmail);
    return { success: true, message: 'Email envoyé' };
  } catch (err) {
    console.error('❌ Erreur envoi email:', err);
    return { success: false, message: err.toString() };
  }
}

// ---------- حفظ الطلب في Google Sheet ----------
function saveToSpreadsheet(data, orderId, requestId, storeKey) {
  try {
    const ss = SpreadsheetApp.openById(SPREADSHEET_ID);
    let sheet = ss.getSheetByName(SHEET_NAME);
    if (!sheet) sheet = ss.insertSheet(SHEET_NAME);
    ensureOrderSheetSchema(sheet);

    if (isRequestInSheet(requestId, storeKey)) {
      console.log('⚠️ Duplicate détecté lors de saveToSpreadsheet -> skip');
      return { success: false, message: 'Duplicate - déjà dans sheet' };
    }

    const idx = getHeaderIndexes(sheet);
    const articlesText = (data.items || []).map(item =>
      `${item.quantity || 1}× ${item.name || 'Produit'} (${item.size || 'N/A'}/${item.color || 'N/A'}) - ${item.finalPrice || item.price || 0} DA`
    ).join(' | ');
    const totalQuantity = (data.items || []).reduce((sum, it) => sum + (parseInt(it.quantity || 1) || 0), 0);

    const row = new Array(17).fill('');
    row[idx.StoreKey] = storeKey;
    row[idx.RequestID] = requestId;
    row[idx['Date et Heure']] = new Date().toLocaleString('fr-FR');
    row[idx['ID Commande']] = orderId;
    row[idx['Nom Client']] = data.customerName || '';
    row[idx['Téléphone']] = data.customerPhone || '';
    row[idx.Commune] = data.customerCommune || '';
    row[idx.Adresse] = data.customerAddress || '';
    row[idx.Wilaya] = data.wilaya || '';
    row[idx['Type Livraison']] = data.deliveryType === 'desk' ? 'Bureau' : 'Domicile';
    row[idx['Articles Commandés']] = articlesText;
    row[idx['Quantité Totale']] = totalQuantity;
    row[idx['Sous-total']] = data.subtotal || 0;
    row[idx.Remise] = data.discount || 0;
    row[idx['Frais Livraison']] = data.deliveryCost || 0;
    row[idx['Total Général']] = data.total || 0;
    row[idx.Statut] = 'En attente';

    sheet.appendRow(row);
    const lastRow = sheet.getLastRow();
    addStatusDropdown(sheet, lastRow);
    formatNewRow(sheet, lastRow);
    console.log('💾 Données sauvegardées dans la ligne:', lastRow);
    return { success: true, row: lastRow };
  } catch (err) {
    console.error('❌ Erreur sauvegarde spreadsheet:', err);
    throw err;
  }
}

// ---------- قائمة الحالة ----------
function addStatusDropdown(sheet, row) {
  try {
    const idx = getHeaderIndexes(sheet);
    const statusColumn = idx.Statut + 1;
    const cell = sheet.getRange(row, statusColumn);
    const rule = SpreadsheetApp.newDataValidation().requireValueInList(ORDER_STATUSES, true).setAllowInvalid(false).build();
    cell.setDataValidation(rule);
    cell.setValue('En attente');
    cell.setBackground('#FFF2CC').setHorizontalAlignment('center').setFontWeight('bold');
  } catch (err) {
    console.error('❌ Erreur dropdown:', err);
  }
}

// ---------- تنسيق الصف الجديد ----------
function formatNewRow(sheet, row) {
  try {
    const numColumns = 17;
    const rowRange = sheet.getRange(row, 1, 1, numColumns);
    rowRange.setBorder(true, true, true, true, true, true);
    const idx = getHeaderIndexes(sheet);
    [idx['Quantité Totale'] + 1, idx['Sous-total'] + 1, idx.Remise + 1, idx['Frais Livraison'] + 1, idx['Total Général'] + 1].forEach(col => {
      try { sheet.getRange(row, col).setNumberFormat('#,##0 "DA"'); } catch(e) { }
    });
    sheet.getRange(row, idx['ID Commande'] + 1).setFontWeight('bold').setBackground('#E6F3FF');
    sheet.autoResizeColumns(1, numColumns);
  } catch (err) {
    console.error('❌ Erreur formatage:', err);
  }
}

// ---------- إنشاء محتوى إيميل ----------
function createEmailBody(data, orderId) {
  const itemsHtml = (data.items || []).map(function(item) {
    const imageHtml = item.image ? `<img src="${item.image}" alt="${item.name || 'Produit'}" style="width:50px;height:50px;object-fit:cover;border-radius:5px;margin-right:8px;">` : '';
    const promoHtml = (item.finalPrice && item.finalPrice !== item.price) ? `<br><small style="color:#FF6B35;">Prix promo: ${formatNumber(item.finalPrice)} DA</small>` : '';
    return `
      <tr>
        <td style="border:1px solid #ddd;padding:8px;">
          <div style="display:flex;align-items:center;">
            ${imageHtml}
            <div>
              <strong>${item.name || 'Non spécifié'}</strong>${promoHtml}
            </div>
          </div>
        </td>
        <td style="border:1px solid #ddd;padding:8px;text-align:center;">${item.quantity || 0}</td>
        <td style="border:1px solid #ddd;padding:8px;text-align:right;">${formatNumber(item.price || 0)} DA</td>
        <td style="border:1px solid #ddd;padding:8px;text-align:right;">${formatNumber((item.finalPrice || item.price || 0) * (item.quantity || 1))} DA</td>
        <td style="border:1px solid #ddd;padding:8px;">${item.size || 'N/A'}</td>
        <td style="border:1px solid #ddd;padding:8px;">
          <div style="display:flex;align-items:center;gap:6px;">
            <div style="width:20px;height:20px;border-radius:50%;background-color:${getColorHex(item.color)};border:1px solid #ddd;"></div>
            ${item.color || 'N/A'}
          </div>
        </td>
      </tr>`;
  }).join('');
  const deliveryType = data.deliveryType === 'desk' ? 'Livraison au bureau' : 'Livraison à domicile';
  const freeDeliveryText = data.isFreeDelivery ? '<span style="color:#06D6A0;font-weight:bold;">OUI (Livraison Gratuite)</span>' : '<span style="color:#FF9E16;">NON</span>';
  return `
  <!DOCTYPE html>
  <html lang="fr">
  <head><meta charset="utf-8"></head>
  <body style="font-family:Arial, sans-serif;color:#333;max-width:800px;margin:0 auto;padding:20px;background:#f9f9f9;">
    <div style="background:linear-gradient(135deg,#4A6CF7,#00D4FF);color:#fff;padding:25px;border-radius:10px;text-align:center;margin-bottom:20px;">
      <h1 style="margin:0;">🎉 NOUVELLE COMMANDE REÇUE 🎉</h1>
      <div style="font-size:18px;margin-top:8px;">${orderId}</div>
    </div>
    <div style="background:#fff;padding:15px;border-radius:8px;margin-bottom:12px;">
      <h3>📋 Informations du Client</h3>
      <p><strong>Nom:</strong> ${data.customerName || 'Non spécifié'}</p>
      <p><strong>Téléphone:</strong> ${data.customerPhone || 'Non spécifié'}</p>
      <p><strong>Adresse:</strong> ${data.customerAddress || 'Non spécifié'} — ${data.customerCommune || ''} — ${data.wilaya || ''}</p>
    </div>
    <div style="background:#fff;padding:15px;border-radius:8px;margin-bottom:12px;">
      <h3>🚚 Livraison</h3>
      <p><strong>Type:</strong> ${deliveryType}</p>
      <p><strong>Frais:</strong> ${formatNumber(data.deliveryCost || 0)} DA</p>
      <p><strong>Livraison gratuite:</strong> ${freeDeliveryText}</p>
    </div>
    <div style="background:#fff;padding:15px;border-radius:8px;margin-bottom:12px;">
      <h3>🛒 Détails des Articles</h3>
      <table style="width:100%;border-collapse:collapse;font-size:14px;">
        <thead>
          <tr>
            <th style="background:#4A6CF7;color:#fff;padding:10px;text-align:left;">Produit</th>
            <th style="background:#4A6CF7;color:#fff;padding:10px;">Quantité</th>
            <th style="background:#4A6CF7;color:#fff;padding:10px;text-align:right;">Prix Unitaire</th>
            <th style="background:#4A6CF7;color:#fff;padding:10px;text-align:right;">Total</th>
            <th style="background:#4A6CF7;color:#fff;padding:10px;">Taille</th>
            <th style="background:#4A6CF7;color:#fff;padding:10px;">Couleur</th>
          </tr>
        </thead>
        <tbody>${itemsHtml}</tbody>
      </table>
    </div>
    <div style="background:linear-gradient(135deg,#fff9e6,#ffe6cc);padding:12px;border-radius:8px;border:2px solid #FF9E16;">
      <p><strong>Sous-total:</strong> ${formatNumber(data.subtotal || 0)} DA</p>
      ${data.discount > 0 ? `<p><strong>Remise:</strong> -${formatNumber(data.discount || 0)} DA</p>` : ''}
      <p><strong>Frais livraison:</strong> ${formatNumber(data.deliveryCost || 0)} DA</p>
      <h3 style="color:#06D6A0;">TOTAL: ${formatNumber(data.total || 0)} DA</h3>
    </div>
    <p style="color:#666;font-size:12px;margin-top:18px;">Email généré automatiquement - ${new Date().toLocaleString('fr-FR')}</p>
  </body>
  </html>`;
}

// ---------- خريطة الألوان ----------
function getColorHex(colorName) {
  const colorMap = {
    "كما في الصورة": "#4A6CF7", "أبيض": "#ffffff", "أسود": "#000000", "رمادي": "#808080",
    "أزرق": "#3498db", "أحمر": "#e74c3c", "أخضر": "#2ecc71", "زهري": "#e84393",
    "بنفسجي": "#9b59b6", "Rouge": "#e74c3c", "Bleu": "#3498db", "Vert": "#2ecc71",
    "Rose": "#e84393", "Violet": "#9b59b6", "Blanc": "#ffffff", "Noir": "#000000", "Gris": "#808080"
  };
  return colorMap[colorName] || "#bdc3c7";
}
function formatNumber(number) {
  try { return new Intl.NumberFormat('fr-FR').format(Number(number || 0)); } catch (e) { return number; }
}

// ---------- اختبار محلي ----------
function testOrderSubmission() {
  const testData = {
    storeKey: 'test.pages.dev',
    storeName: 'TEST STORE',
    customerName: "Jean Dupont", customerPhone: "0550123456", customerAddress: "123 Rue de la République",
    customerCommune: "Alger Centre", wilaya: "Alger", deliveryType: "home", deliveryCost: 600,
    subtotal: 15000, discount: 1500, total: 14100, isFreeDelivery: false,
    items: [
      { name: "Chemise élégante", quantity: 2, price: 5000, finalPrice: 4500, size: "M", color: "Bleu" },
      { name: "Pantalon classique", quantity: 1, price: 6000, finalPrice: 6000, size: "42", color: "Noir" }
    ]
  };
  return processOrderDirect(testData);
}

// ---------- GET ----------
function doGet(e) {
  return ContentService.createTextOutput(JSON.stringify({
    status: 'active', message: 'Service Google Apps Script opérationnel!',
    timestamp: new Date().toLocaleString('fr-FR'), quota: MailApp.getRemainingDailyQuota()
  })).setMimeType(ContentService.MimeType.JSON);
}
function sendResponse(status, message, extra) {
  var payload = Object.assign({ status: status, message: message }, extra || {});
  return ContentService.createTextOutput(JSON.stringify(payload)).setMimeType(ContentService.MimeType.JSON);
}

// =====================================================================
// StoreMaster — Secure Multi-Tenant Orders API
// =====================================================================
function normalizeStoreKey(value) {
  return String(value || '').trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').replace(/^\/+|\/+$/g, '');
}
function isValidOrdersApiSecret(secret) {
  const configured = String(PropertiesService.getScriptProperties().getProperty(ORDERS_API_SECRET_PROPERTY) || '').trim();
  return Boolean(configured && String(secret || '').trim() === configured);
}
function getHeaderIndexes(sheet) {
  const lastColumn = Math.max(sheet.getLastColumn(), 17);
  const headers = sheet.getRange(1, 1, 1, lastColumn).getValues()[0].map(v => String(v || '').trim());
  const index = {};
  headers.forEach((h, i) => index[h] = i);
  ['StoreKey','RequestID','Date et Heure','ID Commande','Nom Client','Téléphone','Commune','Adresse','Wilaya','Type Livraison','Articles Commandés','Quantité Totale','Sous-total','Remise','Frais Livraison','Total Général','Statut'].forEach(h => { if (!(h in index)) index[h] = -1; });
  return index;
}
function ensureOrderSheetSchema(sheet) {
  if (sheet.getLastRow() === 0) {
    const headers = ['StoreKey','RequestID','Date et Heure','ID Commande','Nom Client','Téléphone','Commune','Adresse','Wilaya','Type Livraison','Articles Commandés','Quantité Totale','Sous-total','Remise','Frais Livraison','Total Général','Statut'];
    sheet.getRange(1, 1, 1, headers.length).setValues([headers]);
    sheet.getRange(1, 1, 1, headers.length).setBackground('#4A6CF7').setFontColor('white').setFontWeight('bold').setHorizontalAlignment('center');
    sheet.setFrozenRows(1);
    return;
  }
  const first = String(sheet.getRange(1, 1).getValue() || '').trim();
  const second = String(sheet.getRange(1, 2).getValue() || '').trim();
  if (first !== 'StoreKey' && second === 'RequestID') {
    sheet.insertColumnBefore(1);
    sheet.getRange(1, 1).setValue('StoreKey');
  } else if (first !== 'StoreKey' && first !== 'RequestID') {
    const headers = ['StoreKey','RequestID','Date et Heure','ID Commande','Nom Client','Téléphone','Commune','Adresse','Wilaya','Type Livraison','Articles Commandés','Quantité Totale','Sous-total','Remise','Frais Livraison','Total Général','Statut'];
    for (let i = 0; i < headers.length; i++) if (String(sheet.getRange(1, i + 1).getValue() || '').trim() !== headers[i]) sheet.getRange(1, i + 1).setValue(headers[i]);
  }
  const idx = getHeaderIndexes(sheet);
  if (idx.Statut >= 0) {
    const rule = SpreadsheetApp.newDataValidation().requireValueInList(ORDER_STATUSES, true).setAllowInvalid(false).build();
    if (sheet.getMaxRows() > 1) sheet.getRange(2, idx.Statut + 1, sheet.getMaxRows() - 1, 1).setDataValidation(rule);
  }
  sheet.setFrozenRows(1);
}
function processOrderDirect(data) {
  const storeKey = normalizeStoreKey(data.storeKey);
  if (!storeKey) throw new Error('StoreKey obligatoire');
  const requestId = generateRequestId(data, storeKey);
  const lock = LockService.getScriptLock();
  lock.waitLock(30000);
  try {
    if (isRequestInSheet(requestId, storeKey)) return { success: true, message: 'Commande déjà enregistrée', requestId };
    const orderId = generateOrderId();
    saveToSpreadsheet(data, orderId, requestId, storeKey);

    if (!isEmailSentForRequest(requestId)) {
      const emailResult = sendSingleEmail(data, orderId, STORE_EMAIL, data.storeName || STORE_NAME);
      if (emailResult.success) markEmailAsSent(requestId);
    }
    markRequestAsCompleted(requestId);
    return { success: true, orderId, requestId, storeKey };
  } finally { try { lock.releaseLock(); } catch (_) {} }
}
function apiListOrders(body) {
  const storeKey = normalizeStoreKey(body.storeKey);
  if (!storeKey) throw new Error('StoreKey obligatoire');
  const sheet = getOrdersSheet();
  const idx = getHeaderIndexes(sheet);
  const lastRow = sheet.getLastRow();
  const orders = [];
  if (lastRow >= 2) {
    const values = sheet.getRange(2, 1, lastRow - 1, sheet.getLastColumn()).getValues();
    values.forEach((row, n) => {
      if (normalizeStoreKey(row[idx.StoreKey]) !== storeKey) return;
      const order = rowToOrder(row, idx, n + 2);
      if (matchesOrderFilters(order, body.filters || {})) orders.push(order);
    });
  }
  orders.sort((a,b) => (parseOrderDate(b.timestamp)?.getTime() || 0) - (parseOrderDate(a.timestamp)?.getTime() || 0));
  return { success: true, orders: orders, stats: buildOrderStats(orders) };
}
function apiGetOrder(body) {
  const storeKey = normalizeStoreKey(body.storeKey), orderId = String(body.orderId || '').trim();
  if (!storeKey || !orderId) throw new Error('storeKey et orderId obligatoires');
  const sheet = getOrdersSheet(), idx = getHeaderIndexes(sheet), lastRow = sheet.getLastRow();
  if (lastRow < 2) return { success:false, error:'Commande introuvable' };
  const values = sheet.getRange(2,1,lastRow-1,sheet.getLastColumn()).getValues();
  for (let i=0;i<values.length;i++) {
    if (normalizeStoreKey(values[i][idx.StoreKey]) === storeKey && String(values[i][idx['ID Commande']] || '') === orderId) return { success:true, order:rowToOrder(values[i],idx,i+2) };
  }
  return { success:false, error:'Commande introuvable' };
}
function apiUpdateOrderStatus(body) {
  const storeKey = normalizeStoreKey(body.storeKey), orderId = String(body.orderId || '').trim(), status = String(body.status || '').trim();
  if (!storeKey || !orderId || !status) throw new Error('Paramètres de mise à jour incomplets');
  if (ORDER_STATUSES.indexOf(status) === -1) throw new Error('Statut non autorisé');
  const sheet = getOrdersSheet(), idx = getHeaderIndexes(sheet), lastRow = sheet.getLastRow();
  if (lastRow < 2) return { success:false, error:'Commande introuvable' };
  const values = sheet.getRange(2,1,lastRow-1,sheet.getLastColumn()).getValues();
  for (let i=0;i<values.length;i++) {
    if (normalizeStoreKey(values[i][idx.StoreKey]) === storeKey && String(values[i][idx['ID Commande']] || '') === orderId) {
      const rowNumber = i + 2;
      sheet.getRange(rowNumber, idx.Statut + 1).setValue(status);
      if (status === 'En attente') sheet.getRange(rowNumber, idx.Statut + 1).setBackground('#FFF2CC');
      else if (status === 'Confirmée') sheet.getRange(rowNumber, idx.Statut + 1).setBackground('#D9EAF7');
      else if (status === 'En cours de livraison') sheet.getRange(rowNumber, idx.Statut + 1).setBackground('#E8DDF7');
      else if (status === 'Livrée') sheet.getRange(rowNumber, idx.Statut + 1).setBackground('#D9EAD3');
      return { success:true, order:rowToOrder(sheet.getRange(rowNumber,1,1,sheet.getLastColumn()).getValues()[0],idx,rowNumber) };
    }
  }
  return { success:false, error:'Commande introuvable' };
}
function rowToOrder(row, idx, rowNumber) {
  const articlesText = String(row[idx['Articles Commandés']] || '');
  return {
    row: rowNumber,
    storeKey: String(row[idx.StoreKey] || ''), requestId: String(row[idx.RequestID] || ''),
    timestamp: String(row[idx['Date et Heure']] || ''), orderId: String(row[idx['ID Commande']] || ''),
    customerName: String(row[idx['Nom Client']] || ''), customerPhone: String(row[idx['Téléphone']] || ''),
    customerCommune: String(row[idx.Commune] || ''), customerAddress: String(row[idx.Adresse] || ''),
    wilaya: String(row[idx.Wilaya] || ''), deliveryType: String(row[idx['Type Livraison']] || ''),
    itemsText: articlesText, totalPieces: Number(row[idx['Quantité Totale']] || 0),
    subtotal: Number(row[idx['Sous-total']] || 0), discount: Number(row[idx.Remise] || 0),
    deliveryCost: Number(row[idx['Frais Livraison']] || 0), total: Number(row[idx['Total Général']] || 0),
    status: String(row[idx.Statut] || 'En attente')
  };
}
function matchesOrderFilters(o, f) {
  const q = String(f.search || '').trim().toLowerCase();
  if (q && ![o.orderId,o.customerName,o.customerPhone,o.wilaya,o.customerCommune,o.itemsText].some(v => String(v || '').toLowerCase().includes(q))) return false;
  if (f.status && o.status !== f.status) return false;
  if (f.deliveryType) {
    const wanted = String(f.deliveryType).toLowerCase();
    if (wanted === 'desk' && !o.deliveryType.toLowerCase().includes('bureau')) return false;
    if (wanted === 'home' && !o.deliveryType.toLowerCase().includes('domicile')) return false;
  }
  const orderDate = parseOrderDate(o.timestamp);
  if (orderDate && f.dateFrom) {
    const from = new Date(String(f.dateFrom) + 'T00:00:00');
    if (orderDate < from) return false;
  }
  if (orderDate && f.dateTo) {
    const to = new Date(String(f.dateTo) + 'T23:59:59');
    if (orderDate > to) return false;
  }
  return true;
}
function parseOrderDate(value) {
  if (value instanceof Date) return value;
  const s = String(value || '').trim();
  let m = s.match(/^(\d{1,2})[\/](\d{1,2})[\/](\d{4})(?:,?\s+(\d{1,2}):(\d{2})(?::(\d{2}))?)?/);
  if (m) return new Date(Number(m[3]), Number(m[2])-1, Number(m[1]), Number(m[4]||0), Number(m[5]||0), Number(m[6]||0));
  const d = new Date(s);
  return isNaN(d.getTime()) ? null : d;
}
function buildOrderStats(orders) {
  return { total:orders.length, pending:orders.filter(o=>o.status==='En attente').length, confirmed:orders.filter(o=>o.status==='Confirmée').length, delivery:orders.filter(o=>o.status==='En cours de livraison').length, delivered:orders.filter(o=>o.status==='Livrée').length };
}
function getOrdersSheet() { const ss=SpreadsheetApp.openById(SPREADSHEET_ID); const sheet=ss.getSheetByName(SHEET_NAME)||ss.insertSheet(SHEET_NAME); ensureOrderSheetSchema(sheet); return sheet; }
function ordersApi(body) {
  if (!isValidOrdersApiSecret(body.secret)) return {success:false,error:'Accès non autorisé'};
  const action=String(body.action||'').trim();
  if (action==='createOrder') {
    const data=body.data||{}; data.storeKey=normalizeStoreKey(body.storeKey); data.storeName=String(body.storeName||'').trim();
    return processOrderDirect(data);
  }
  if (action==='list') return apiListOrders(body);
  if (action==='get') return apiGetOrder(body);
  if (action==='updateStatus') return apiUpdateOrderStatus(body);
  if (action==='setup') return setupOrdersApi();
  return {success:false,error:'Action inconnue'};
}
function setupOrdersApi() {
  const sheet=getOrdersSheet();
  let secret=PropertiesService.getScriptProperties().getProperty(ORDERS_API_SECRET_PROPERTY);
  if (!secret) { secret=Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,''); PropertiesService.getScriptProperties().setProperty(ORDERS_API_SECRET_PROPERTY,secret); }
  return {success:true,message:'Sheet prête et Secret configuré',secret:secret,columns:sheet.getLastColumn()};
}

// ---------- دوال إدارة عامة ----------
function clearAllProcessedRequests() {
  try { const props=PropertiesService.getScriptProperties(); const keys=Object.keys(props.getProperties()||{}); keys.forEach(k=>props.deleteProperty(k)); console.log('🧹 Toutes les requêtes ont été nettoyées'); return {success:true}; }
  catch(err){console.error('Erreur nettoyage:',err);return {success:false,error:err.toString()};}
}
function showProcessedRequests() {
  try { const props=PropertiesService.getScriptProperties(); const p=props.getProperties(); console.log('📋 Requêtes actuelles:',p); return p; }
  catch(err){console.error('Erreur affichage:',err);return {};}
}
